﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ChangeScene : MonoBehaviour {
    public string m_sceneName;
	// Use this for initialization
	void Start ()
    {
        SceneManager.sceneLoaded += OnLoadedScene;
    }

    // Update is called once per frame
    void Update ()
    {
		if(Input.GetKeyDown(KeyCode.Space))
        {
            PhotonNetwork.isMessageQueueRunning = false;
            GetComponent<PhotonView>().RPC("LoadScene", PhotonTargets.All, m_sceneName);
        }
    }

    [PunRPC]
    void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    void OnLoadedScene(Scene i_scene, LoadSceneMode i_mode)
    {
        PhotonNetwork.isMessageQueueRunning = true;
    }
}
