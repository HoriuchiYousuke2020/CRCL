﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Makoto
{
    public class GameDirector : MonoBehaviour
    {
        // Use this for initialization
        void Start()
        {
            GameObject obj = PhotonNetwork.Instantiate("Player1", new Vector3(0, 1, 0), Quaternion.identity, 0);
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
