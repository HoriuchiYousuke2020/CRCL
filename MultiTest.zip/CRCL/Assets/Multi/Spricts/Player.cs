﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace Makoto
{
    public class Player : MonoBehaviour
    {
        private Rigidbody rb;

        private PhotonView photonView;

        // Use this for initialization
        void Start()
        {
            rb = GetComponent<Rigidbody>();

            photonView = GetComponent<PhotonView>();
        }

        // Update is called once per frame
        void Update()
        {
            if (photonView.isMine)
            {
                if (Input.GetKey(KeyCode.LeftArrow))
                {
                    Left();
                }
                else if (Input.GetKey(KeyCode.RightArrow))
                {
                    Right();
                }
                else if (Input.GetKey(KeyCode.UpArrow))
                {
                    Up();
                }
                else if (Input.GetKey(KeyCode.DownArrow))
                {
                    Down();
                }
            }
        }

        public void Left()
        {
            rb.AddForce(new Vector3(-50, 0, 0));
            Debug.Log("l");
        }

        public void Right()
        {
            rb.AddForce(new Vector3(50, 0, 0));
            Debug.Log("r");
        }

        public void Up()
        {
            rb.AddForce(new Vector3(0, 0, 50));
            Debug.Log("u");
        }

        public void Down()
        {
            rb.AddForce(new Vector3(0, 0, -50));
            Debug.Log("d");
        }
    }
}
