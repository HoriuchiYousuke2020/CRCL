﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Makoto
{
    public class RoomList : MonoBehaviour
    {
        [SerializeField]
        private Dropdown dropdown = null;

        [SerializeField]
        private Text roomName = null;

        // Use this for initialization
        void Start()
        {
            if (PhotonNetwork.GetRoomList().Length == 0)
            {
                Debug.Log("部屋なし");
            }
            else
            {
                List<string> r = new List<string>();
                foreach (RoomInfo room in PhotonNetwork.GetRoomList())
                {
                    r.Add(room.Name);
                }

                dropdown.AddOptions(r);
            }

            SceneManager.sceneLoaded += OnLoadedScene;
        }

        // Update is called once per frame
        void Update()
        {

        }

        void OnJoinedRoom()
        {
            PhotonNetwork.isMessageQueueRunning = false;
            //SceneManager.LoadScene("PlayScene");
            //SceneManager.LoadScene("GameScene");
            SceneManager.LoadScene("StandByScene");
        }

        void OnLoadedScene(Scene i_scene, LoadSceneMode i_mode)
        {
            PhotonNetwork.isMessageQueueRunning = true;
        }

        public void Random()
        {
            PhotonNetwork.JoinRandomRoom();
        }

        public void Create()
        {
            SceneManager.LoadScene("CreateRoomScene");
        }

        public void Reload()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        public void JoinRoom()
        {
            PhotonNetwork.JoinRoom(roomName.text);
        }
    }
}
