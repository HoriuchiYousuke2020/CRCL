﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Makoto
{
    public class JoinLobby : MonoBehaviour
    {
        [SerializeField]
        private Text playerNameText;

        // Use this for initialization
        void Start()
        {

        }

        // ロビーに入ると呼ばれる
        void OnJoinedLobby()
        {
            Debug.Log("ロビーに入りました。");

            PhotonNetwork.playerName = playerNameText.text;

            SceneManager.LoadScene("RoomListScene");
        }

        public void Joine()
        {
            // Photonに接続する(引数でゲームのバージョンを指定できる)
            PhotonNetwork.ConnectUsingSettings(null);
        }
    }
}
