﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Makoto
{
    public class Cube : MonoBehaviour
    {
        [SerializeField]
        [Range(1.0f, 10.0f)]
        private float DELETE_TIME;

        private float startTime, currentTime;

        // Use this for initialization
        void Start()
        {
            startTime = Time.realtimeSinceStartup;
        }

        // Update is called once per frame
        void Update()
        {
            currentTime = Time.realtimeSinceStartup;

            if (currentTime - startTime >= DELETE_TIME)
            {
                Destroy(this.gameObject);
            }
        }
    }
}
