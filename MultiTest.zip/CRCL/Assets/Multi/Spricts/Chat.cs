﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Makoto
{
    public class Chat : MonoBehaviour
    {
        [SerializeField]
        private Text[] text = new Text[11];

        [SerializeField]
        private InputField input;

        private List<string> st = new List<string>();

        private PhotonView photonView;

        private string playerName;

        // Use this for initialization
        void Start()
        {
            photonView = GetComponent<PhotonView>();

            playerName = PhotonNetwork.playerName;

            photonView.RPC("TextUpdate", PhotonTargets.All);
        }

        // Update is called once per frame
        void Update()
        {

        }

        public void Button()
        {
            photonView.RPC("AddText", PhotonTargets.AllBuffered, input.text, playerName);
            photonView.RPC("TextUpdate", PhotonTargets.All);
            input.text = "";
        }

        [PunRPC]
        void AddText(string text, string name)
        {
            if (st.Count == 11)
            {
                st.RemoveAt(0);
            }

            st.Add(name + "   :   " + text);
        }

        [PunRPC]
        void TextUpdate()
        {
            for (int i = 0; i < st.Count; i++)
            {
                text[i].text = st[i];
            }
        }
    }
}
