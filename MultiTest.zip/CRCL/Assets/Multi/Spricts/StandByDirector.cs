﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Makoto
{
    public class StandByDirector : MonoBehaviour
    {
        [SerializeField]
        private GameObject[] playerName = new GameObject[4];

        [SerializeField]
        private GameObject[] ready = new GameObject[4];

        private int playerNumber = 0;

        public int MyNumber
        {
            get { return playerNumber; }
        }

        private PhotonView photonView;

        private bool readyState;

        private int[] playerIds = new int[4];

        private string[] playerNames = new string[4];
        public string[] Names
        {
            get { return playerNames; }
        }

        private bool state;

        // Use this for initialization
        void Start()
        {
            photonView = GetComponent<PhotonView>();

            readyState = false;

            playerNumber = PhotonNetwork.playerList.Length - 1;

            photonView.RPC("AddId", PhotonTargets.AllBuffered, playerNumber, PhotonNetwork.player.ID);

            photonView.RPC("Name", PhotonTargets.AllBuffered, playerNumber, PhotonNetwork.playerName);

            photonView.RPC("NameText", PhotonTargets.AllBuffered, playerNumber, PhotonNetwork.playerName);

            SceneManager.sceneLoaded += OnLoadedScene;

            state = true;
        }

        // Update is called once per frame
        void Update()
        {
            if (state)
            {
                int i = 0;

                for (int j = 0; j < 4; j++)
                {
                    if (ready[j].GetComponent<Text>().text == "Ready!")
                    {
                        i++;
                    }
                }

                if (i == 4)
                {
                    DontDestroyOnLoad(this);
                    DontDestroyOnLoad(GameObject.Find("Chat"));
                    PhotonNetwork.isMessageQueueRunning = false;
                    SceneManager.LoadScene("GameScene");

                    state = false;
                }
            }
        }

        public void Button()
        {
            if (readyState)
            {
                readyState = false;
            }
            else
            {
                readyState = true;
            }

            photonView.RPC("Ready", PhotonTargets.All, playerNumber, readyState);
        }

        public void StartButton()
        {
            photonView.RPC("RPCLoadScene", PhotonTargets.All, "GameScene");
        }

        [PunRPC]
        void Ready(int num, bool state)
        {
            if (state)
            {
                ready[num].GetComponent<Text>().text = "Ready!";
            }
            else
            {
                ready[num].GetComponent<Text>().text = "";
            }
        }

        [PunRPC]
        void Name(int num, string name)
        {
            playerNames[num] = name;
        }

        [PunRPC]
        void NameText(int num, string name)
        {
            playerName[num].GetComponent<Text>().text = name;
        }

        [PunRPC]
        void RPCLoadScene(string name)
        {
            DontDestroyOnLoad(this);
            DontDestroyOnLoad(GameObject.Find("Chat"));
            PhotonNetwork.isMessageQueueRunning = false;
            SceneManager.LoadScene(name);
            state = false;
        }

        [PunRPC]
        void AddId(int num, int id)
        {
            playerIds[num] = id;
        }

        void OnLoadedScene(Scene i_scene, LoadSceneMode i_mode)
        {
            PhotonNetwork.isMessageQueueRunning = true;
        }

        public void ReturnLobby()
        {
            PhotonNetwork.LeaveRoom();
        }

        public void OnLeftRoom()
        {
            SceneManager.LoadScene("RoomListScene");
        }
    }
}
