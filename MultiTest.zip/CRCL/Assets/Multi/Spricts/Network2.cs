﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

namespace Makoto
{
    public class Network2 : MonoBehaviour
    {
        private StandByDirector data;

        GameObject obj;

        void Start()
        {
            data = GameObject.Find("StandByDirector").GetComponent<StandByDirector>();

            switch (data.MyNumber)
            {
                case 0:
                    obj = PhotonNetwork.Instantiate("Player1", new Vector3(2, 2, 0), Quaternion.identity, 0);
                    break;
                case 1:
                    obj = PhotonNetwork.Instantiate("Player2", new Vector3(-2, 2, 0), Quaternion.identity, 0);
                    break;
                case 2:
                    obj = PhotonNetwork.Instantiate("Player3", new Vector3(4, 2, 0), Quaternion.identity, 0);
                    break;
                case 3:
                    obj = PhotonNetwork.Instantiate("Player4", new Vector3(-4, 2, 0), Quaternion.identity, 0);
                    break;
            }
        }

        void Update()
        {
            for (int i = 0; i < 4; i++)
            {
                if (GameObject.Find("Player" + (i + 1).ToString() + "(Clone)"))
                {
                    GameObject.Find("Player" + (i + 1).ToString() + "(Clone)").name = data.Names[i];
                    GetComponent<CameraTarget>().player[i] = GameObject.Find(data.Names[i]);
                    GameObject.Find("CheckPlayers").GetComponent<CheckPlayers>().m_players[i] = GameObject.Find(data.Names[i]).GetComponent<PlayerController>();
                }
            }



            ////生成位置をランダムな座標にする
            //float x = Random.Range(-5f, 5f);
            //float y = Random.Range(-5f, 5f);
            ////float z = Random.Range(-10f, 10f);
            //Vector3 pos = new Vector3(x, y, -5);

            //// 左クリックをしたらマッチング環境にCubeのインスタンスを生成する
            //if (Input.GetMouseButton(0))
            //{

            //    // 第1引数にResourcesフォルダの中にあるプレハブの名前(文字列)
            //    // 第2引数にposition
            //    // 第3引数にrotation
            //    // 第4引数にView ID(指定しない場合は0)
            //    GameObject obj = PhotonNetwork.Instantiate("Cube", pos, Quaternion.identity, 0);

            //    // 生成したオブジェクトに力を加える
            //    Rigidbody objRB = obj.GetComponent<Rigidbody>();
            //    objRB.AddForce(Vector3.forward * 20f, ForceMode.Impulse);
            //}
        }

        public void ReturnLobby()
        {
            PhotonNetwork.LeaveRoom();
        }

        public void OnLeftRoom()
        {
            Destroy(GameObject.Find("StandByDirector"));
            Destroy(GameObject.Find("Chat"));
            SceneManager.LoadScene("RoomListScene");
        }

        [PunRPC]
        void NameChange(string name)
        {
            obj.name = name;
        }
    }
}
