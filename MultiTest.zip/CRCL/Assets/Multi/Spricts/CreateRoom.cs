﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

namespace Makoto
{
    public class CreateRoom : MonoBehaviour
    {
        [SerializeField]
        private Text roomName;

        void Start()
        {

        }

        // ルームに入室すると呼ばれる
        void OnJoinedRoom()
        {
            Debug.Log(PhotonNetwork.room.Name + "ルームへ入室しました。");

            //SceneManager.LoadScene("PlayScene");
            //SceneManager.LoadScene("GameScene");
            SceneManager.LoadScene("StandByScene");
        }

        // ルームの入室に失敗すると呼ばれる
        void OnPhotonRandomJoinFailed()
        {
            Debug.Log("ルームの入室に失敗しました。");
        }

        public void Create()
        {
            PhotonNetwork.CreateRoom(roomName.text);
        }
    }
}